
package modifier;

/**
 *
 * @author Aldi
 */
public class Orang {
    
    protected String nama;
    
    public void buatNama(String nama){
        this.nama = nama;
    }
    public String tampilNama(){
        return this.nama;
    }
}
