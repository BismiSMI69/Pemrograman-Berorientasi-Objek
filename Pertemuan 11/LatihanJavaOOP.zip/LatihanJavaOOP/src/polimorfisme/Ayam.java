
package polimorfisme;

/**
 *
 * @author Aldi
 */
public class Ayam extends Hewan{
    @Override
    public void bersuara(){
        System.out.println("Petok....Petok....");
    }
}
