
package polimorfisme;

/**
 *
 * @author Aldi
 */
public class Hewan {
    public void bersuara(){
        System.out.println("Hewan dapat bersuara");
    }
}
