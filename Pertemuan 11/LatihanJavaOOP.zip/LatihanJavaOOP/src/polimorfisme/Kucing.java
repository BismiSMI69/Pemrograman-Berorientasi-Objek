
package polimorfisme;

/**
 *
 * @author Aldi
 */
public class Kucing extends Hewan{
    
    @Override
    public void bersuara(){
        System.out.println("Meonggg....");
    }
    
}
